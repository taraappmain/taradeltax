import streamlit as st

st.set_page_config(page_title="Tara Unified Dashboard", layout="wide")
st.title("🚀 Tara Marketplace Unified Dashboard")
st.write("Dashboard online. Modules coming soon...")
