import requests
from bs4 import BeautifulSoup

def fetch_go_supps_products():
    url = "https://www.gosupps.com/"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    products = []
    for item in soup.select('.product-item-info')[:10]:  # limit to 10 items
        try:
            title = item.select_one('.product-item-link').get_text(strip=True)
            link = item.select_one('.product-item-link')['href']
            image = item.select_one('img')['data-src']
            price = item.select_one('.price').get_text(strip=True)
            products.append({
                'title': title,
                'link': link,
                'image': image,
                'price': price
            })
        except Exception:
            continue
    return products