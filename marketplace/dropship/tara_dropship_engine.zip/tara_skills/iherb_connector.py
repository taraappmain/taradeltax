def fetch_iherb_products():
    # Placeholder: iHerb requires affiliate feed/API — simulation for now
    sample_products = [
        {"title": "Vitamin D3 5000 IU", "link": "https://iherb.com/product/d3", "image": "https://example.com/d3.jpg", "price": "$12.99"},
        {"title": "Omega-3 Fish Oil", "link": "https://iherb.com/product/omega3", "image": "https://example.com/o3.jpg", "price": "$18.49"}
    ]
    return sample_products